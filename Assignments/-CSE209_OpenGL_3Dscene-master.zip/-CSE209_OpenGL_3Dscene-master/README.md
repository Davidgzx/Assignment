# -CSE209_OpenGL_3Dscene
A design which created a terrain scene developed on c++ using OpenGL API. Simple skybox terrain
@auther: Zixuan.guo

## Features
- Skybox 
- Terrain 

## Environment and instruction 
	Visual Studio 2015 with c++ extension(Windows)
	GLUT OpenGL utility toolkit.
	Window 10 professional version 1703
