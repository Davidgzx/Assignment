# -CSE209_OpenGL_2DxmasCard
A design which created a typical Christmas card developed on c++ using OpenGL API.
@auther: Zixuan.guo

## Geometric objects

- Cloud
- Tree
- Gift
- House
- The face of Santa
- Snowflake

## Environment and instruction 
	Visual Studio 2015 with c++ extension(Windows)
	GLUT OpenGL utility toolkit.
	Window 10 professional version 1703


![Xmas card](https://github.com/Davidgzx/-CSE209_OpenGL_2DxmasCard/blob/master/2.jpg)
