# -CSE205_PythonNetwork_Crawler
A low-level python image crawler only using standard python library (without urllib2)  based on socket programming
## Features
-	Support both http and https without urllib2
-	Download images in the pages based on html parser
-	Depth control based on Depth-first search (Attention: Origin page is depth 1)
-	Parallel multi-threading

### Because I don't spend time on avoiding code duplication, this code is not somehow elegant. 
